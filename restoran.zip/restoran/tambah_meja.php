<!DOCTYPE html>

<?php
include "connection/koneksi.php";
session_start();
ob_start();
//echo $_SESSION['edit_menu'];
$id = $_SESSION['id_user'];

if (isset($_SESSION['username'])) {

  $query = "select * from tb_user natural join tb_level where id_user = $id";

  mysqli_query($conn, $query);
  $sql = mysqli_query($conn, $query);

  $id_meja = "";
  $nomor_meja = "";
  $status_meja = "";

  if (isset($_SESSION['edit_meja'])) {
    $id_meja = $_SESSION['edit_meja'];
    $query_data_edit = "select * from tb_meja where id_meja = $id_meja";
    $sql_data_edit = mysqli_query($conn, $query_data_edit);
    $result_data_edit = mysqli_fetch_array($sql_data_edit);

    $nomor_meja = $result_data_edit['nomor_meja'];
    $status_meja = $result_data_edit['status_meja'];
  }

  while ($r = mysqli_fetch_array($sql)) {

    $nama_user = $r['nama_user'];

?>

    <html lang="en">

    <head>
        <title>Tambah Meja</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="template/dashboard/css/bootstrap.min.css" />
        <link rel="stylesheet" href="template/dashboard/css/bootstrap-responsive.min.css" />
        <link rel="stylesheet" href="template/dashboard/css/fullcalendar.css" />
        <link rel="stylesheet" href="template/dashboard/css/matrix-style.css" />
        <link rel="stylesheet" href="template/dashboard/css/matrix-media.css" />
        <link href="template/dashboard/font-awesome/css/font-awesome.css" rel="stylesheet" />
        <link rel="stylesheet" href="template/dashboard/css/jquery.gritter.css" />
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
    </head>

    <body>

        <!--Header-part-->
        <div id="header">
            <h1><a href="entri_meja.php">Tambah Meja</a></h1>
        </div>
        <!--close-Header-part-->


        <!--top-Header-menu-->
        <div id="user-nav" class="navbar navbar-inverse">
            <ul class="nav">
                <li class="dropdown" id="profile-messages"><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i> <span class="text">Welcome <?php echo $r['nama_user']; ?></span><b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="#"><i class="icon-user"></i><?php echo "&nbsp;&nbsp;" . $r['nama_level']; ?></a></li>
                        <li><a href="logout.php"><i class="icon-key"></i> Log Out</a></li>
                    </ul>
                </li>
                <li class=""><a title="" href="logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
            </ul>
        </div>
        <!--close-top-Header-menu-->
        <!--start-top-serch-->

        <!--close-top-serch-->
        <!--sidebar-menu-->
        <div id="sidebar">
            <a href="entri_meja.php" class="visible-phone">
                <i class="icon icon-tasks"></i> <span>Entri Meja</span>
            </a>
            <ul>
                <li><a href="beranda.php"><i class="icon icon-home"></i> <span>Beranda</span></a> </li>
                <li class="active"> <a href="tambah_meja.php"><i class="icon icon-tasks"></i> <span>Tambah Meja</span></a> </li>
                <li> <a href="widgets.html"><i class="icon icon-shopping-cart"></i> <span>Entri Order</span></a> </li>
                <li> <a href="widgets.html"><i class="icon icon-inbox"></i> <span>Entri Transaksi</span></a> </li>
                <li> <a href="widgets.html"><i class="icon icon-print"></i> <span>Generate Laporan</span></a> </li>
            </ul>
        </div>
        <!--sidebar-menu-->

        <!--main-container-part-->
        <div id="content">
            <!--breadcrumbs-->
            <div id="content-header">
                <div id="breadcrumb">
                    <a href="tambah_meja.php" title="Tambah Meja" class="tip-bottom">
                        <i class="icon icon-tasks"></i>
                        Tambah Meja
                    </a>
                    <?php
                    if (isset($_SESSION['edit_meja'])) {
                    ?>
                        <a href="entri_meja.php" title="Ubah Detail Meja" class="tip-bottom">
                            <i class="icon icon-tasks"></i>
                            Ubah Detail Meja
                        </a>
                    <?php
                    }
                    ?>
                </div>
            </div>
            <!--End-breadcrumbs-->

            <!--Action boxes-->
            <div class="container-fluid">
                <div class="row-fluid">
                    <?php
                    if ($r['id_level'] == 1) {
                    ?>
                        <div class="widget-box span6">
                            <div class="widget-title bg_lg"><span class="icon"><i class="icon-th-large"></i></span>
                                <h5>Tambah Meja</h5>
                            </div>
                            <div class="widget-content">
                                <form action="" method="post" class="form-horizontal">
                                    <div class="control-group">
                                        <label class="control-label">Nomor Meja:</label>
                                        <div class="controls">
                                            <?php
                                            if (isset($_SESSION['edit_meja'])) {
                                            ?>
                                                <input name="nomor_meja" type="text" value="<?php echo $nomor_meja; ?>" class="span11" placeholder="Nomor Meja" disabled="" />
                                                <input name="nomor_meja" type="hidden" value="<?php echo $nomor_meja; ?>" class="span11" placeholder="Nomor Meja" />
                                            <?php
                                            } else {
                                            ?>
                                                <input name="nomor_meja" type="text" value="" class="span11" placeholder="Nomor Meja" />
                                            <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="form-actions">
                                        <?php
                                        if (isset($_SESSION['edit_meja'])) {
                                        ?>
                                            <button type="submit" name="ubah_meja" class="btn btn-info"><i class='icon icon-save'></i>&nbsp; Simpan Perubahan</button>
                                        <?php
                                        } else {
                                        ?>
                                            <button type="submit" name="tambah_meja" class="btn btn-success"><i class='icon icon-plus'></i>&nbsp; Tambahkan</button>
                                        <?php
                                        }
                                        ?>
                                        <button type="submit" name="batal_meja" class="btn btn-danger"><i class='icon icon-remove'></i>&nbsp; Batalkan</a>
                                    </div>
                                </form>
                                <?php
                                if (isset($_POST['tambah_meja'])) {
                                    $nomor_meja = $_POST['nomor_meja'];

                                    $query_tambah_meja = "insert into tb_meja (nomor_meja, status_meja) values ('$nomor_meja', 'kosong')";
                                    $sql_tambah_meja = mysqli_query($conn, $query_tambah_meja);
                                    if ($sql_tambah_meja) {
                                        header('location: tambah_meja.php');
                                    }
                                }
                                if (isset($_REQUEST['batal_meja'])) {
                                    if (isset($_SESSION['edit_meja'])) {
                                        unset($_SESSION['edit_meja']);
                                    }
                                    header('location: tambah_meja.php');
                                }

                                if (isset($_POST['ubah_meja'])) {
                                    $nomor_meja = $_POST['nomor_meja'];

                                    $query_ubah_meja = "update tb_meja set nomor_meja = '$nomor_meja' where id_meja = '$id_meja'";
                                    $sql_ubah_meja = mysqli_query($conn, $query_ubah_meja);

                                    if ($sql_ubah_meja) {
                                        unset($_SESSION['edit_meja']);
                                        header('location: tambah_meja.php');
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
                <!--End-Action boxes-->
            </div>
        </div>

        <script type="text/javascript">
            // Your existing JavaScript code
        </script>

        <!--end-main-container-part-->

        <!--Footer-part-->

        <div class="row-fluid">
            <div id="footer" class="span12"> <?php echo date('Y'); ?> &copy; Restaurant <a href="#">by henscorp</a> </div>
        </div>

        <!--end-Footer-part-->

        <script src="template/dashboard/js/excanvas.min.js"></script>
        <script src="template/dashboard/js/jquery.min.js"></script>
        <script src="template/dashboard/js/jquery.ui.custom.js"></script>
        <script src="template/dashboard/js/bootstrap.min.js"></script>
        <script src="template/dashboard/js/jquery.flot.min.js"></script>
        <script src="template/dashboard/js/jquery.flot.resize.min.js"></script>
        <script src="template/dashboard/js/jquery.peity.min.js"></script>
        <script src="template/dashboard/js/fullcalendar.min.js"></script>
        <script src="template/dashboard/js/matrix.js"></script>
        <script src="template/dashboard/js/matrix.dashboard.js"></script>
        <script src="template/dashboard/js/jquery.gritter.min.js"></script>
        <script src="template/dashboard/js/matrix.interface.js"></script>
        <script src="template/dashboard/js/matrix.chat.js"></script>
        <script src="template/dashboard/js/jquery.validate.js"></script>
        <script src="template/dashboard/js/matrix.form_validation.js"></script>
        <script src="template/dashboard/js/jquery.wizard.js"></script>
        <script src="template/dashboard/js/jquery.uniform.js"></script>
        <script src="template/dashboard/js/select2.min.js"></script>
        <script src="template/dashboard/js/matrix.popover.js"></script>
        <script src="template/dashboard/js/jquery.dataTables.min.js"></script>
        <script src="template/dashboard/js/matrix.tables.js"></script>

        <!-- Your existing scripts -->

    </body>

    </html>
<?php
    }
} else {
    header('location: logout.php');
}
ob_flush();
?>
